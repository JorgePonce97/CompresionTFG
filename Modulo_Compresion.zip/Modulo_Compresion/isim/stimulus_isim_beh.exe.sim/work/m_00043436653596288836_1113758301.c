/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/TFG/Modulo_Compresion/LUT_N_BITS.v";
static unsigned int ng1[] = {16U, 0U};
static unsigned int ng2[] = {13U, 0U};
static unsigned int ng3[] = {0U, 0U};
static unsigned int ng4[] = {2U, 0U};
static unsigned int ng5[] = {1U, 0U};
static unsigned int ng6[] = {4U, 0U};
static unsigned int ng7[] = {4095U, 0U};
static unsigned int ng8[] = {5U, 0U};
static unsigned int ng9[] = {4094U, 0U};
static unsigned int ng10[] = {3U, 0U};
static unsigned int ng11[] = {7U, 0U};
static unsigned int ng12[] = {4093U, 0U};
static unsigned int ng13[] = {4092U, 0U};
static unsigned int ng14[] = {8U, 0U};
static unsigned int ng15[] = {4091U, 0U};
static unsigned int ng16[] = {6U, 0U};
static unsigned int ng17[] = {4090U, 0U};
static unsigned int ng18[] = {4089U, 0U};
static unsigned int ng19[] = {4088U, 0U};



static void Always_18_0(char *t0)
{
    char t13[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    int t19;

LAB0:    t1 = (t0 + 2680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(18, ng0);
    t2 = (t0 + 3000);
    *((int *)t2) = 1;
    t3 = (t0 + 2712);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(19, ng0);

LAB5:    xsi_set_current_line(20, ng0);
    t4 = (t0 + 1048U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(23, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB12;

LAB10:    if (*((unsigned int *)t2) == 0)
        goto LAB9;

LAB11:    t4 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t4) = 1;

LAB12:    t5 = (t13 + 4);
    t14 = *((unsigned int *)t5);
    t15 = (~(t14));
    t16 = *((unsigned int *)t13);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB13;

LAB14:    xsi_set_current_line(26, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);

LAB16:    t2 = ((char*)((ng3)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng5)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng7)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng4)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng9)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng10)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB27;

LAB28:    t2 = ((char*)((ng12)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB29;

LAB30:    t2 = ((char*)((ng6)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB31;

LAB32:    t2 = ((char*)((ng13)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB33;

LAB34:    t2 = ((char*)((ng8)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB35;

LAB36:    t2 = ((char*)((ng15)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB37;

LAB38:    t2 = ((char*)((ng16)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB39;

LAB40:    t2 = ((char*)((ng17)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB41;

LAB42:    t2 = ((char*)((ng11)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB43;

LAB44:    t2 = ((char*)((ng18)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB45;

LAB46:    t2 = ((char*)((ng14)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB47;

LAB48:    t2 = ((char*)((ng19)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 12, t2, 12);
    if (t19 == 1)
        goto LAB49;

LAB50:
LAB52:
LAB51:    xsi_set_current_line(62, ng0);
    t2 = ((char*)((ng1)));
    t4 = (t0 + 1768);
    xsi_vlogvar_assign_value(t4, t2, 0, 0, 5);

LAB53:
LAB15:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(21, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 1768);
    xsi_vlogvar_assign_value(t12, t11, 0, 0, 5);
    goto LAB8;

LAB9:    *((unsigned int *)t13) = 1;
    goto LAB12;

LAB13:    xsi_set_current_line(24, ng0);
    t11 = ((char*)((ng2)));
    t12 = (t0 + 1768);
    xsi_vlogvar_assign_value(t12, t11, 0, 0, 5);
    goto LAB15;

LAB17:    xsi_set_current_line(28, ng0);
    t4 = ((char*)((ng4)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB19:    xsi_set_current_line(30, ng0);
    t4 = ((char*)((ng6)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB21:    xsi_set_current_line(32, ng0);
    t4 = ((char*)((ng6)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB23:    xsi_set_current_line(34, ng0);
    t4 = ((char*)((ng8)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB25:    xsi_set_current_line(36, ng0);
    t4 = ((char*)((ng8)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB27:    xsi_set_current_line(38, ng0);
    t4 = ((char*)((ng11)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB29:    xsi_set_current_line(40, ng0);
    t4 = ((char*)((ng11)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB31:    xsi_set_current_line(42, ng0);
    t4 = ((char*)((ng11)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB33:    xsi_set_current_line(44, ng0);
    t4 = ((char*)((ng11)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB35:    xsi_set_current_line(46, ng0);
    t4 = ((char*)((ng14)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB37:    xsi_set_current_line(48, ng0);
    t4 = ((char*)((ng14)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB39:    xsi_set_current_line(50, ng0);
    t4 = ((char*)((ng14)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB41:    xsi_set_current_line(52, ng0);
    t4 = ((char*)((ng14)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB43:    xsi_set_current_line(54, ng0);
    t4 = ((char*)((ng14)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB45:    xsi_set_current_line(56, ng0);
    t4 = ((char*)((ng14)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB47:    xsi_set_current_line(58, ng0);
    t4 = ((char*)((ng14)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

LAB49:    xsi_set_current_line(60, ng0);
    t4 = ((char*)((ng14)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB53;

}


extern void work_m_00043436653596288836_1113758301_init()
{
	static char *pe[] = {(void *)Always_18_0};
	xsi_register_didat("work_m_00043436653596288836_1113758301", "isim/stimulus_isim_beh.exe.sim/work/m_00043436653596288836_1113758301.didat");
	xsi_register_executes(pe);
}
