/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/TFG/Modulo_Compresion/Comparador.v";



static void Cont_18_0(char *t0)
{
    char t4[8];
    char t14[8];
    char t22[8];
    char t38[8];
    char t48[8];
    char t58[8];
    char t62[8];
    char t96[8];
    char t106[8];
    char t114[8];
    char t130[8];
    char t140[8];
    char t150[8];
    char t154[8];
    char t186[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;
    char *t39;
    char *t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t49;
    char *t50;
    char *t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    char *t59;
    char *t60;
    char *t61;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    char *t66;
    char *t67;
    char *t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    char *t76;
    char *t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    int t86;
    int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    char *t94;
    char *t95;
    char *t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    char *t104;
    char *t105;
    char *t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    char *t115;
    char *t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    char *t129;
    char *t131;
    char *t132;
    char *t133;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    char *t141;
    char *t142;
    char *t143;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    char *t151;
    char *t152;
    char *t153;
    unsigned int t155;
    unsigned int t156;
    unsigned int t157;
    char *t158;
    char *t159;
    char *t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    unsigned int t166;
    unsigned int t167;
    char *t168;
    char *t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    int t178;
    int t179;
    unsigned int t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    char *t190;
    char *t191;
    char *t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    char *t200;
    char *t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    int t205;
    unsigned int t206;
    unsigned int t207;
    unsigned int t208;
    int t209;
    unsigned int t210;
    unsigned int t211;
    unsigned int t212;
    unsigned int t213;
    char *t214;
    char *t215;
    char *t216;
    char *t217;
    char *t218;
    unsigned int t219;
    unsigned int t220;
    char *t221;
    unsigned int t222;
    unsigned int t223;
    char *t224;
    unsigned int t225;
    unsigned int t226;
    char *t227;

LAB0:    t1 = (t0 + 2680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(18, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4);
    t5 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 11);
    t8 = (t7 & 1);
    *((unsigned int *)t4) = t8;
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 11);
    t11 = (t10 & 1);
    *((unsigned int *)t2) = t11;
    t12 = (t0 + 1208U);
    t13 = *((char **)t12);
    memset(t14, 0, 8);
    t12 = (t14 + 4);
    t15 = (t13 + 4);
    t16 = *((unsigned int *)t13);
    t17 = (t16 >> 11);
    t18 = (t17 & 1);
    *((unsigned int *)t14) = t18;
    t19 = *((unsigned int *)t15);
    t20 = (t19 >> 11);
    t21 = (t20 & 1);
    *((unsigned int *)t12) = t21;
    memset(t22, 0, 8);
    t23 = (t4 + 4);
    t24 = (t14 + 4);
    t25 = *((unsigned int *)t4);
    t26 = *((unsigned int *)t14);
    t27 = (t25 ^ t26);
    t28 = *((unsigned int *)t23);
    t29 = *((unsigned int *)t24);
    t30 = (t28 ^ t29);
    t31 = (t27 | t30);
    t32 = *((unsigned int *)t23);
    t33 = *((unsigned int *)t24);
    t34 = (t32 | t33);
    t35 = (~(t34));
    t36 = (t31 & t35);
    if (t36 != 0)
        goto LAB7;

LAB4:    if (t34 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t22) = 1;

LAB7:    t39 = (t0 + 1368U);
    t40 = *((char **)t39);
    memset(t38, 0, 8);
    t39 = (t38 + 4);
    t41 = (t40 + 4);
    t42 = *((unsigned int *)t40);
    t43 = (t42 >> 0);
    *((unsigned int *)t38) = t43;
    t44 = *((unsigned int *)t41);
    t45 = (t44 >> 0);
    *((unsigned int *)t39) = t45;
    t46 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t46 & 2047U);
    t47 = *((unsigned int *)t39);
    *((unsigned int *)t39) = (t47 & 2047U);
    t49 = (t0 + 1208U);
    t50 = *((char **)t49);
    memset(t48, 0, 8);
    t49 = (t48 + 4);
    t51 = (t50 + 4);
    t52 = *((unsigned int *)t50);
    t53 = (t52 >> 0);
    *((unsigned int *)t48) = t53;
    t54 = *((unsigned int *)t51);
    t55 = (t54 >> 0);
    *((unsigned int *)t49) = t55;
    t56 = *((unsigned int *)t48);
    *((unsigned int *)t48) = (t56 & 2047U);
    t57 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t57 & 2047U);
    memset(t58, 0, 8);
    t59 = (t38 + 4);
    if (*((unsigned int *)t59) != 0)
        goto LAB9;

LAB8:    t60 = (t48 + 4);
    if (*((unsigned int *)t60) != 0)
        goto LAB9;

LAB12:    if (*((unsigned int *)t38) > *((unsigned int *)t48))
        goto LAB10;

LAB11:    t63 = *((unsigned int *)t22);
    t64 = *((unsigned int *)t58);
    t65 = (t63 & t64);
    *((unsigned int *)t62) = t65;
    t66 = (t22 + 4);
    t67 = (t58 + 4);
    t68 = (t62 + 4);
    t69 = *((unsigned int *)t66);
    t70 = *((unsigned int *)t67);
    t71 = (t69 | t70);
    *((unsigned int *)t68) = t71;
    t72 = *((unsigned int *)t68);
    t73 = (t72 != 0);
    if (t73 == 1)
        goto LAB13;

LAB14:
LAB15:    t94 = (t0 + 1368U);
    t95 = *((char **)t94);
    memset(t96, 0, 8);
    t94 = (t96 + 4);
    t97 = (t95 + 4);
    t98 = *((unsigned int *)t95);
    t99 = (t98 >> 11);
    t100 = (t99 & 1);
    *((unsigned int *)t96) = t100;
    t101 = *((unsigned int *)t97);
    t102 = (t101 >> 11);
    t103 = (t102 & 1);
    *((unsigned int *)t94) = t103;
    t104 = (t0 + 1048U);
    t105 = *((char **)t104);
    memset(t106, 0, 8);
    t104 = (t106 + 4);
    t107 = (t105 + 4);
    t108 = *((unsigned int *)t105);
    t109 = (t108 >> 11);
    t110 = (t109 & 1);
    *((unsigned int *)t106) = t110;
    t111 = *((unsigned int *)t107);
    t112 = (t111 >> 11);
    t113 = (t112 & 1);
    *((unsigned int *)t104) = t113;
    memset(t114, 0, 8);
    t115 = (t96 + 4);
    t116 = (t106 + 4);
    t117 = *((unsigned int *)t96);
    t118 = *((unsigned int *)t106);
    t119 = (t117 ^ t118);
    t120 = *((unsigned int *)t115);
    t121 = *((unsigned int *)t116);
    t122 = (t120 ^ t121);
    t123 = (t119 | t122);
    t124 = *((unsigned int *)t115);
    t125 = *((unsigned int *)t116);
    t126 = (t124 | t125);
    t127 = (~(t126));
    t128 = (t123 & t127);
    if (t128 != 0)
        goto LAB19;

LAB16:    if (t126 != 0)
        goto LAB18;

LAB17:    *((unsigned int *)t114) = 1;

LAB19:    t131 = (t0 + 1368U);
    t132 = *((char **)t131);
    memset(t130, 0, 8);
    t131 = (t130 + 4);
    t133 = (t132 + 4);
    t134 = *((unsigned int *)t132);
    t135 = (t134 >> 0);
    *((unsigned int *)t130) = t135;
    t136 = *((unsigned int *)t133);
    t137 = (t136 >> 0);
    *((unsigned int *)t131) = t137;
    t138 = *((unsigned int *)t130);
    *((unsigned int *)t130) = (t138 & 2047U);
    t139 = *((unsigned int *)t131);
    *((unsigned int *)t131) = (t139 & 2047U);
    t141 = (t0 + 1048U);
    t142 = *((char **)t141);
    memset(t140, 0, 8);
    t141 = (t140 + 4);
    t143 = (t142 + 4);
    t144 = *((unsigned int *)t142);
    t145 = (t144 >> 0);
    *((unsigned int *)t140) = t145;
    t146 = *((unsigned int *)t143);
    t147 = (t146 >> 0);
    *((unsigned int *)t141) = t147;
    t148 = *((unsigned int *)t140);
    *((unsigned int *)t140) = (t148 & 2047U);
    t149 = *((unsigned int *)t141);
    *((unsigned int *)t141) = (t149 & 2047U);
    memset(t150, 0, 8);
    t151 = (t130 + 4);
    if (*((unsigned int *)t151) != 0)
        goto LAB21;

LAB20:    t152 = (t140 + 4);
    if (*((unsigned int *)t152) != 0)
        goto LAB21;

LAB24:    if (*((unsigned int *)t130) < *((unsigned int *)t140))
        goto LAB22;

LAB23:    t155 = *((unsigned int *)t114);
    t156 = *((unsigned int *)t150);
    t157 = (t155 & t156);
    *((unsigned int *)t154) = t157;
    t158 = (t114 + 4);
    t159 = (t150 + 4);
    t160 = (t154 + 4);
    t161 = *((unsigned int *)t158);
    t162 = *((unsigned int *)t159);
    t163 = (t161 | t162);
    *((unsigned int *)t160) = t163;
    t164 = *((unsigned int *)t160);
    t165 = (t164 != 0);
    if (t165 == 1)
        goto LAB25;

LAB26:
LAB27:    t187 = *((unsigned int *)t62);
    t188 = *((unsigned int *)t154);
    t189 = (t187 | t188);
    *((unsigned int *)t186) = t189;
    t190 = (t62 + 4);
    t191 = (t154 + 4);
    t192 = (t186 + 4);
    t193 = *((unsigned int *)t190);
    t194 = *((unsigned int *)t191);
    t195 = (t193 | t194);
    *((unsigned int *)t192) = t195;
    t196 = *((unsigned int *)t192);
    t197 = (t196 != 0);
    if (t197 == 1)
        goto LAB28;

LAB29:
LAB30:    t214 = (t0 + 3080);
    t215 = (t214 + 56U);
    t216 = *((char **)t215);
    t217 = (t216 + 56U);
    t218 = *((char **)t217);
    memset(t218, 0, 8);
    t219 = 1U;
    t220 = t219;
    t221 = (t186 + 4);
    t222 = *((unsigned int *)t186);
    t219 = (t219 & t222);
    t223 = *((unsigned int *)t221);
    t220 = (t220 & t223);
    t224 = (t218 + 4);
    t225 = *((unsigned int *)t218);
    *((unsigned int *)t218) = (t225 | t219);
    t226 = *((unsigned int *)t224);
    *((unsigned int *)t224) = (t226 | t220);
    xsi_driver_vfirst_trans(t214, 0, 0);
    t227 = (t0 + 3000);
    *((int *)t227) = 1;

LAB1:    return;
LAB6:    t37 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t37) = 1;
    goto LAB7;

LAB9:    t61 = (t58 + 4);
    *((unsigned int *)t58) = 1;
    *((unsigned int *)t61) = 1;
    goto LAB11;

LAB10:    *((unsigned int *)t58) = 1;
    goto LAB11;

LAB13:    t74 = *((unsigned int *)t62);
    t75 = *((unsigned int *)t68);
    *((unsigned int *)t62) = (t74 | t75);
    t76 = (t22 + 4);
    t77 = (t58 + 4);
    t78 = *((unsigned int *)t22);
    t79 = (~(t78));
    t80 = *((unsigned int *)t76);
    t81 = (~(t80));
    t82 = *((unsigned int *)t58);
    t83 = (~(t82));
    t84 = *((unsigned int *)t77);
    t85 = (~(t84));
    t86 = (t79 & t81);
    t87 = (t83 & t85);
    t88 = (~(t86));
    t89 = (~(t87));
    t90 = *((unsigned int *)t68);
    *((unsigned int *)t68) = (t90 & t88);
    t91 = *((unsigned int *)t68);
    *((unsigned int *)t68) = (t91 & t89);
    t92 = *((unsigned int *)t62);
    *((unsigned int *)t62) = (t92 & t88);
    t93 = *((unsigned int *)t62);
    *((unsigned int *)t62) = (t93 & t89);
    goto LAB15;

LAB18:    t129 = (t114 + 4);
    *((unsigned int *)t114) = 1;
    *((unsigned int *)t129) = 1;
    goto LAB19;

LAB21:    t153 = (t150 + 4);
    *((unsigned int *)t150) = 1;
    *((unsigned int *)t153) = 1;
    goto LAB23;

LAB22:    *((unsigned int *)t150) = 1;
    goto LAB23;

LAB25:    t166 = *((unsigned int *)t154);
    t167 = *((unsigned int *)t160);
    *((unsigned int *)t154) = (t166 | t167);
    t168 = (t114 + 4);
    t169 = (t150 + 4);
    t170 = *((unsigned int *)t114);
    t171 = (~(t170));
    t172 = *((unsigned int *)t168);
    t173 = (~(t172));
    t174 = *((unsigned int *)t150);
    t175 = (~(t174));
    t176 = *((unsigned int *)t169);
    t177 = (~(t176));
    t178 = (t171 & t173);
    t179 = (t175 & t177);
    t180 = (~(t178));
    t181 = (~(t179));
    t182 = *((unsigned int *)t160);
    *((unsigned int *)t160) = (t182 & t180);
    t183 = *((unsigned int *)t160);
    *((unsigned int *)t160) = (t183 & t181);
    t184 = *((unsigned int *)t154);
    *((unsigned int *)t154) = (t184 & t180);
    t185 = *((unsigned int *)t154);
    *((unsigned int *)t154) = (t185 & t181);
    goto LAB27;

LAB28:    t198 = *((unsigned int *)t186);
    t199 = *((unsigned int *)t192);
    *((unsigned int *)t186) = (t198 | t199);
    t200 = (t62 + 4);
    t201 = (t154 + 4);
    t202 = *((unsigned int *)t200);
    t203 = (~(t202));
    t204 = *((unsigned int *)t62);
    t205 = (t204 & t203);
    t206 = *((unsigned int *)t201);
    t207 = (~(t206));
    t208 = *((unsigned int *)t154);
    t209 = (t208 & t207);
    t210 = (~(t205));
    t211 = (~(t209));
    t212 = *((unsigned int *)t192);
    *((unsigned int *)t192) = (t212 & t210);
    t213 = *((unsigned int *)t192);
    *((unsigned int *)t192) = (t213 & t211);
    goto LAB30;

}


extern void work_m_10542279647402385808_2523135212_init()
{
	static char *pe[] = {(void *)Cont_18_0};
	xsi_register_didat("work_m_10542279647402385808_2523135212", "isim/stimulus_isim_beh.exe.sim/work/m_10542279647402385808_2523135212.didat");
	xsi_register_executes(pe);
}
